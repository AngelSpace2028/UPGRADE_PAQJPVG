from ._paq import *

__version__ = '0.1.1'
